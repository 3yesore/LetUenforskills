# LetUen Skill Anchor Pack v0.2.0-dev

LetUen decomposes Agent Skills into evidence-grounded explanations, reusable anchors, Obsidian-ready notes, and non-destructive composition plans.

This package contains the lightweight method skills only. It does not bundle the full local web UI or Python harness.

## Contents

- `SKILL.md` — main pack entry and operating contract.
- `skills/asa-*/SKILL.md` — internal method skills.
- `ANCHOR_SCHEMA.md` — anchor data contract.
- `COMPOSITION_FORMS.md` — reuse/composition forms.
- `HARNESS_INTEGRATION.md` — how a host harness should call the skills.
- `NON_DESTRUCTIVE_INVOCATION.md` — trigger and mutation safety policy.
- `EVIDENCE_REPAIR.md` — source-aware evidence repair behavior.
- `examples/` — anchor composition example.

## Install Shape

Install the whole directory as one skill pack, or copy individual `skills/asa-*` method skills into an existing harness that already has a coordinator.

## Release Status

Developer preview. Deterministic quality gates pass on the DeepSeek v4pro five-skill benchmark after source-aware evidence repair, but broader multi-model public benchmark claims are still pending.
