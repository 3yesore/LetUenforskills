# Evidence Repair

LetUen requires source-grounded evidence before a decomposition can be treated as publishable.

A host harness should run a source-aware evidence repair pass after model generation and before final quality gating.

Expected behavior:

1. Resolve every evidence object back to its source file.
2. If the quote is an exact source substring, keep it.
3. If the quote is a paraphrase of a nearby source line, replace it with the exact source line or a short exact source substring.
4. If no reliable source match exists, downgrade the evidence to `inferred`, lower confidence, and record a repair note.
5. Write a repair report so users can audit every change.

In the LetUen Python harness this is implemented by:

```powershell
python -m asa repair-evidence --run <run-dir>
python -m asa quality-run --run <run-dir>
```

The skill pack itself does not require this exact CLI, but any compatible harness should implement equivalent behavior before publishing reports.
