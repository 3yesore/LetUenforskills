---
name: LetUen
description: Use when decomposing Agent Skills or workflow repositories into evidence-grounded reports, reusable anchors, Obsidian notes, and non-destructive composition plans.
version: v0.2.0-dev
internal_meta_skill_pack: true
non_destructive_by_default: true
output_contract: letuen.skill_anatomy_report + letuen.anchor_pack + letuen.obsidian_vault
---

# LetUen Skill Anatomy Pack

Use LetUen when the user wants to understand, compare, reuse, or recombine Agent Skills without blindly copying an entire workflow.

LetUen is not a single heavy workflow. It is an anchor-aware skill pack that can be used as:

- a decomposition guide,
- a quality/evidence gate,
- a reusable anchor extractor,
- a lightweight composition planner,
- an Obsidian/report authoring method,
- a development benchmark helper.

## Activation

Use this pack when the request mentions:

- decomposing a `SKILL.md` package,
- analyzing an agent skill repository,
- extracting reusable workflow parts,
- comparing model outputs for skill analysis,
- generating Obsidian learning notes from a skill,
- composing anchors without modifying existing user skills.

Do not use this pack as a generic coding helper. Do not override existing user skills with the same trigger. If trigger ownership is unclear, prefer the existing user skill and use LetUen as a sidecar analysis layer.

## Operating Contract

- Read source files before making claims.
- Keep quotes short and source-backed.
- Run evidence repair or equivalent source-aware quote checking before publishing.
- Emit anchors as sidecar assets by default.
- Do not mutate existing user skill directories unless the user explicitly asks.
- If solidifying a workflow, first produce a dry-run plan and ask for approval.

## Method Skill Order

1. `asa-skill-identity-decomposer`
2. `asa-trigger-boundary-mapper`
3. `asa-resource-role-analyzer`
4. `asa-workflow-trace-builder`
5. `asa-evidence-grounding-auditor`
6. `asa-reuse-pattern-miner`
7. `asa-reader-layer-writer`
8. `asa-anchor-composition-planner`
9. `asa-model-comparison-judge` only for development/model comparison tests

## Required Outputs

For a complete decomposition, produce or preserve:

- identity summary,
- trigger/boundary map,
- resource role map,
- workflow trace,
- evidence audit,
- reusable anchors,
- reader-facing report layers,
- optional composition plan,
- explicit unsupported-claim list.

## Quality Gate

A result is not publishable until:

- deterministic schema validation passes,
- evidence quote checks pass,
- unsupported high-confidence claims are removed or downgraded,
- existing user skill structure is preserved,
- generated anchors include risk and reuse metadata.
