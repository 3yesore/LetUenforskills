# Call Order

1. Identity decomposer
2. Trigger/boundary mapper
3. Resource role analyzer
4. Workflow trace builder
5. Evidence grounding auditor
6. Reuse pattern miner
7. Reader layer writer
8. Anchor composition planner
9. Model comparison judge only for development benchmarks

The evidence repair pass runs after model artifacts are produced and before deterministic publishability checks.
