# Install Check

After unpacking, verify:

```text
letuen-skill-anchor-pack/SKILL.md
letuen-skill-anchor-pack/PACK_MANIFEST.json
letuen-skill-anchor-pack/skills/asa-anchor-composition-planner/SKILL.md
letuen-skill-anchor-pack/skills/asa-evidence-grounding-auditor/SKILL.md
letuen-skill-anchor-pack/skills/asa-model-comparison-judge/SKILL.md
letuen-skill-anchor-pack/skills/asa-reader-layer-writer/SKILL.md
letuen-skill-anchor-pack/skills/asa-resource-role-analyzer/SKILL.md
letuen-skill-anchor-pack/skills/asa-reuse-pattern-miner/SKILL.md
letuen-skill-anchor-pack/skills/asa-skill-identity-decomposer/SKILL.md
letuen-skill-anchor-pack/skills/asa-trigger-boundary-mapper/SKILL.md
letuen-skill-anchor-pack/skills/asa-workflow-trace-builder/SKILL.md
```

Expected method skill count: 9.

Do not install this pack in a way that overrides existing user skills with the same trigger. LetUen should run as a sidecar analysis/composition layer unless explicitly selected.
